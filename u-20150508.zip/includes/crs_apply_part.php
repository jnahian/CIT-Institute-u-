<div class="container pd0">
    <div class="col-md-3 col-sm-4 pd0">
        <a class="crsBtn" href="oneyear_diploma.php">
            <p>discover</p><span>1 year diploma course</span>
        </a>
    </div>
    <div class="col-md-6 col-sm-4 pd0 crsbtm">
        <img src="images/course/crsFFd.jpg" alt="" class="img-responsive">
    </div>
    <div class="col-md-3 col-sm-4 pd0">
        <a class="crsBtn" href="apply_online.php">
            <p>apply now</p><span>Online Form</span>
        </a>
    </div>
</div>