<?php
	require_once('functions/function.php');
	$oPageContents->get_header();
	$oPageContents->get_nav(); 
?>
	<section>
		<div class="full" id="fdBkBanner">
			<div class="container">
                <h1 class="bnrHdr" id="link">student's feedback</h1>
				<p class="bnrTxt">Creative IT student feedback</p>
			</div>
			<div class="container">
				<div class="bnrBdr"></div>
			</div>
		</div>
		<!--container end-->
	</section>
	<!--banner part end-->
	<section class="stFdBk">

        <div class="container marB20">
            <p class="evntHtx"><b>Success</b>  <span>stories</span>
            </p>
            <div class="tGraphics ">
                <div class="col-md-4">
                    <a href="" id="video" data-src="5Omkuu610C8">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/5Omkuu610C8" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="FJakaBHxRt4">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/FJakaBHxRt4" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="crHOf4WnXg8">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/crHOf4WnXg8" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="pnufsqH4nBs">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/pnufsqH4nBs" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="t2nA81vcPgc">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/t2nA81vcPgc" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="igjIxbFOtxU">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/igjIxbFOtxU" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="6wgCB4MoXY4">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/6wgCB4MoXY4" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="gBWaLoVBHqg">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/gBWaLoVBHqg" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="XQLMDli89Js">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/XQLMDli89Js" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="V0CjGyXoZXM">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/V0CjGyXoZXM" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="Jc9lXT9d1_M">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/Jc9lXT9d1_M" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="wUAiizh5iVg">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/wUAiizh5iVg" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="DwdIosEVFBA">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/DwdIosEVFBA" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="NnVLmkCUl2g">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/NnVLmkCUl2g" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="lfAd9jkLEEI">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/lfAd9jkLEEI" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="w_Xjrv7zXuk">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/w_Xjrv7zXuk" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="57Vqi4hu9hg">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/57Vqi4hu9hg" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="lRJsA4pP1bs">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/lRJsA4pP1bs" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="XkEDZTPw7IM">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/XkEDZTPw7IM" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="kjKQYQjzCCs">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/kjKQYQjzCCs" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="3IxSFBHqsxE">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/3IxSFBHqsxE" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="SYiC8LAxHUE">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/SYiC8LAxHUE" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="vRglmpDZfs4">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/vRglmpDZfs4" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="mR6qV5iz">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/mR6qV5iz-i8" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="P9u6MEIK7WU">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/P9u6MEIK7WU" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="4KbKwqnIpfs">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/4KbKwqnIpfs" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="y9whEvp0Tnw">
                        <iframe class="img-responsive" src="//www.youtube.com/embed/y9whEvp0Tnw" frameborder="0" alowfullscreen ></iframe>
                    </a>
                </div>
            </div>
        </div>
        <!--Modal for Video-->
        <div class="modal video" tabindex="-1" role="dialog">
            <div class="modal-dialog"> 
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Online Tutorials</h4>
                    </div>
                    <iframe id="mVideo" width="100%" height="400" src="" frameborder="0" allowfullscreen></iframe>
                </div>
            </div>
        </div>
        
        <!--Modal for Video End-->
<!--
		<div class="container crsHead">
			<p><b>success </b>stories</p>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/5Omkuu610C8" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/FJakaBHxRt4" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/crHOf4WnXg8" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/pnufsqH4nBs" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/t2nA81vcPgc" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
		</div>
-->
</section>
<div class="container ptBdr"></div>
<?php 
	$oPageContents->get_part('partner_part.php');
	$oPageContents->get_footer();
?>
