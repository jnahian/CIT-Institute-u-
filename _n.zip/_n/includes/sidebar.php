<div class="page-sidebar sidebar">
    <div class="page-sidebar-inner slimscroll">
        
        <ul class="menu accordion-menu">

            <li><a href="index.php" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-home"></span><p>Dashboard</p></a>
            <li><a href="m_menu.php" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-tasks"></span><p>Menu Manager</p></a>
            </li>
            <li class="droplink"><a href="#" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-edit"></span><p>Content Manager</p><span class="arrow"></span></a>
                <ul class="sub-menu">
                    <li><a href="m_course.php">Courses</a></li>
                    <li><a href="m_teachers.php">Teachers Profile</a></li>
                    <li><a href="m_press_media.php">Press &amp; media</a></li>
                </ul>
            </li>
            <li class="droplink"><a href="#" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-camera"></span><p>Gallery Manager</p><span class="arrow"></span></a>
                <ul class="sub-menu">
                    <li><a href="">Student Gallery</a></li>
                    <li><a href="">Office Gallery</a></li>
                    <li><a href="">Achivments &amp; Award</a></li>
                    <li><a href="">Events Gallery</a></li>
                </ul>
            </li>
            <li class="droplink"><a href="#" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-bullhorn"></span><p>Event Manager</p><span class="arrow"></span></a>
                <ul class="sub-menu">
                    <li><a href="">Upcoming Event</a></li>
                    <li><a href="">Events Gallery</a></li>
                </ul>
            </li>
            <li><a href="#" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-film"></span><p>Video manager</p></a>
            </li>
            <li><a href="#" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-tag"></span><p>Partnar's manager</p></a>
            </li>
            <li><a href="#" class="waves-effect waves-button"><span class="menu-icon glyphicon glyphicon-user"></span><p>user manager</p></a>
            </li>

        </ul>
    </div>
    <!-- Page Sidebar Inner -->
</div>
<!-- Page Sidebar -->
<div class="page-inner">
    
    
    