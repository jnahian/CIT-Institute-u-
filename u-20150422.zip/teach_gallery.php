<?php
	require_once('functions/function.php');
	$oPageContents->get_header();
	$oPageContents->get_nav(); 
	$oPageContents->get_part('teach_gallery_page.php');
	$oPageContents->get_footer();
?>