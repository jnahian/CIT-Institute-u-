<section>
    <div class="full marT20 marB20">
        <img class="ps1 img-responsive" src="images/pearson.jpg" alt="">
        <img class="ps2 img-responsive" src="images/pearson2.png" alt="">
    </div>
</section><!--pearson part code end-->