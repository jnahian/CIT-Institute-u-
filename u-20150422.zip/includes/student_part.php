<div class="modal fade video" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog"> 
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Students Achivement</h4>
            </div>
            <iframe width="100%" height="400" src="" frameborder="0" allowfullscreen></iframe>
        </div>
    </div>
</div>
   <section>
    <div class="container pd0 marB20">
        <div class="col-md-4 col-sm-6 stuAchivments wow fadeInLeft" data-nahian-offset="200">
            <p>student</p>
            <h3>achivements</h3>
            <a id="video" href="" data-toggle="modal" data-target=".video">
                <img class="img-responsive" src="images/stu-achv.png" alt="">
                <span class="fa fa-play"></span>
            </a>
        </div><!--student achivments end-->
        <div class="col-md-4 col-sm-6 stuAchivments wow fadeInUp" data-nahian-offset="200">
            <p>student</p>
            <h3>feedback</h3>
            <div id="stuFeeds" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#stuFeeds" data-slide-to="0" class="active"></li>
                    <li data-target="#stuFeeds" data-slide-to="1"></li>
                    <li data-target="#stuFeeds" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <p>The education I have learned at Creative IT Institute has been the foundation that I've built a successful career on.</p>
                        <span class="fa fa-quote-left"></span>
                        <br>
                        <b><em>Md. Anowarul Islam</em></b>
                        <br>
                        <i>Digital Designer & Content <br> Executive Multimode Ltd</i>
                    </div>
                    <div class="item">
            <p>The education I have learned at Creative IT Institute has been the foundation that I've built a successful career on.</p>
                        <span class="fa fa-quote-left"></span>
                        <br>
                        <b><em>Md. Anowarul Islam</em></b>
                        <br>
                        <i>Digital Designer & Content <br>Executive Multimode Ltd</i>

                    </div>
                    <div class="item">
            <p>The education I have learned at Creative IT Institute has been the foundation that I've built a successful career on.</p>
                        <span class="fa fa-quote-left"></span>
                        <br>
                        <b><em>Md. Anowarul Islam</em></b>
                        <br>
                        <i>Digital Designer & Content <br>Executive Multimode Ltd</i>

                    </div>
                </div>
            </div>
        </div><!--student feedback end-->
        <div class="col-md-4 stuAchivments bdr0 wow fadeInRight" data-nahian-offset="200">
            <p>career</p>
            <h3>counselling</h3>
            <form class="cConu" action="" role="form" method="post">
                <input class="form-control" type="text" placeholder="First Name">
                <input class="form-control" type="text" placeholder="Last Name">
                <input class="form-control" type="text" placeholder="Phone">
                <input class="form-control" type="email" placeholder="Email">
                <input class="form-control cCsubmit" type="submit" value="SUBMIT">
            </form>
        </div><!--career counselling end-->
    </div><!--container end-->

    
</section>