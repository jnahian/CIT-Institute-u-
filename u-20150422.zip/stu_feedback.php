<?php
	require_once('functions/function.php');
	$oPageContents->get_header();
	$oPageContents->get_nav(); 
?>
	<section>
		<div class="full" id="fdBkBanner">
			<div class="container">
                <h1 class="bnrHdr" id="link">student's feedback</h1>
				<p class="bnrTxt">Creative IT student feedback</p>
			</div>
			<div class="container">
				<div class="bnrBdr"></div>
			</div>
		</div>
		<!--container end-->
	</section>
	<!--banner part end-->
	<section class="stFdBk">
		<div class="container crsHead">
			<p><b>success </b>stories</p>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/5Omkuu610C8" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/FJakaBHxRt4" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/crHOf4WnXg8" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/pnufsqH4nBs" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/t2nA81vcPgc" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/igjIxbFOtxU" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/6wgCB4MoXY4" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/gBWaLoVBHqg" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/XQLMDli89Js" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/V0CjGyXoZXM" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/Jc9lXT9d1_M" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/wUAiizh5iVg" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/DwdIosEVFBA" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/NnVLmkCUl2g" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/lfAd9jkLEEI" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/w_Xjrv7zXuk" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/57Vqi4hu9hg" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/lRJsA4pP1bs" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/XkEDZTPw7IM" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/kjKQYQjzCCs" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/3IxSFBHqsxE" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/SYiC8LAxHUE" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/vRglmpDZfs4" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/mR6qV5iz-i8" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/P9u6MEIK7WU" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/4KbKwqnIpfs" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/y9whEvp0Tnw" frameborder="0" alowfullscreen ></iframe>
			</div>
		</div>
</section>
<div class="container ptBdr"></div>
<?php 
	$oPageContents->get_part('partner_part.php');
	$oPageContents->get_footer();
?>
