$(document).ready(function(){
    $na = $(window).width();
    if( $na >= 767){
        $navOffest = $("nav").offset().top; 
        $crs = $('.naCrs').offset().top;
        $p = $('#partners').offset().top;
        $d = $crs - $navOffest;
        $(window).scroll(function(){
            $scrollPos  = $(window).scrollTop();
            if( $scrollPos >= $d && $scrollPos <= $p ){
                $(".naCrs").addClass("crsFix");
            }
            else{
                $(".naCrs").removeClass("crsFix");
            }
        });
    }
});