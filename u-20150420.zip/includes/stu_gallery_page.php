<section>
    <div class="full" id="galleryBanner">
        <div class="container">
            <h1 class="bnrHdr" id="link">student GALLERY</h1>
            <p class="bnrTxt">Creative IT student gallery</p>
        </div><!--container end-->
        <div class="container">
            <div class="bnrBdr"></div>
        </div><!--container end-->
    </div><!--bannerBanner part end-->
</section>
<section>
<!--
    <div class="container portfolio_filter marT50">
        <ul>
            <li>
                <button class="btn_filter filter" data-filter=".category-1, .category-2, .category-3, .category-4">ALL</button>
            </li>
            <li>
                <button class="btn_filter filter" data-filter=".category-1">office</button>
            </li>
            <li>
                <button class="btn_filter filter" data-filter=".category-2">animation</button>
            </li>
            <li>
                <button class="btn_filter filter" data-filter=".category-3">interior</button>
            </li>
            <li>
                <button class="btn_filter filter" data-filter=".category-4">web</button>
            </li>
        </ul>
    </div>
    <div class="container portfolio_items">
        <div id="Container">
            <div id="port" class="gallery">
                <a class="col-md-3 pd0 mix category-1" href="images/gallery/01.png" data-my-order="1">
                    <img class="img-responsive" src="images/gallery/01.png" title="Hello world" />
                </a>
                <a class="col-md-3 pd0 mix category-2" href="images/gallery/02.png" data-my-order="2">
                    <img class="img-responsive" src="images/gallery/02.png" />
                </a>
                <a class="col-md-3 pd0 mix category-3" href="images/gallery/03.png" data-my-order="3">
                    <img class="img-responsive" src="images/gallery/03.png" />
                </a>
                <a class="col-md-3 pd0 mix category-4" href="images/gallery/04.png" data-my-order="4">
                    <img class="img-responsive" src="images/gallery/04.png" />
                </a>
                <a class="col-md-3 pd0 mix category-4" href="images/gallery/05.png" data-my-order="5">
                    <img class="img-responsive" src="images/gallery/05.png" />
                </a>
                <a class="col-md-3 pd0 mix category-3" href="images/gallery/06.png" data-my-order="6">
                    <img class="img-responsive" src="images/gallery/06.png" />
                </a>
                <a class="col-md-3 pd0 mix category-1" href="images/gallery/07.png" data-my-order="7">
                    <img class="img-responsive" src="images/gallery/07.png" />
                </a>
                <a class="col-md-3 pd0 mix category-2" href="images/gallery/08.png" data-my-order="8">
                    <img class="img-responsive" src="images/gallery/08.png" />
                </a>
                <a class="col-md-3 pd0 mix category-1" href="images/gallery/09.png" data-my-order="1">
                    <img class="img-responsive" src="images/gallery/09.png" title="Hello world" />
                </a>
                <a class="col-md-3 pd0 mix category-2" href="images/gallery/10.png" data-my-order="2">
                    <img class="img-responsive" src="images/gallery/10.png" />
                </a>
                <a class="col-md-3 pd0 mix category-3" href="images/gallery/11.png" data-my-order="3">
                    <img class="img-responsive" src="images/gallery/11.png" />
                </a>
                <a class="col-md-3 pd0 mix category-4" href="images/gallery/12.png" data-my-order="4">
                    <img class="img-responsive" src="images/gallery/12.png" />
                </a>
                <a class="col-md-3 pd0 mix category-4" href="images/gallery/13.png" data-my-order="5">
                    <img class="img-responsive" src="images/gallery/13.png" />
                </a>
                <a class="col-md-3 pd0 mix category-3" href="images/gallery/14.png" data-my-order="6">
                    <img class="img-responsive" src="images/gallery/14.png" />
                </a>
                <a class="col-md-3 pd0 mix category-1" href="images/gallery/15.png" data-my-order="7">
                    <img class="img-responsive" src="images/gallery/15.png" />
                </a>
                <a class="col-md-3 pd0 mix category-2" href="images/gallery168.png" data-my-order="8">
                    <img class="img-responsive" src="images/gallery/16.png" />
                </a>
            </div>
        </div>
    </div>
-->
    <div class="container">
        <div id="port" class="gallery">
            <a class="col-md-3 pd0" href="images/gallery/01.png">
                <img class="img-responsive" src="images/gallery/01.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/02.png">
                <img class="img-responsive" src="images/gallery/02.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/03.png">
                <img class="img-responsive" src="images/gallery/03.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/04.png">
                <img class="img-responsive" src="images/gallery/04.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/05.png">
                <img class="img-responsive" src="images/gallery/05.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/06.png">
                <img class="img-responsive" src="images/gallery/06.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/07.png">
                <img class="img-responsive" src="images/gallery/07.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/08.png">
                <img class="img-responsive" src="images/gallery/08.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/09.png">
                <img class="img-responsive" src="images/gallery/09.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/10.png">
                <img class="img-responsive" src="images/gallery/10.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/11.png">
                <img class="img-responsive" src="images/gallery/11.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/12.png">
                <img class="img-responsive" src="images/gallery/12.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/13.png">
                <img class="img-responsive" src="images/gallery/13.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/14.png">
                <img class="img-responsive" src="images/gallery/14.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/15.png">
                <img class="img-responsive" src="images/gallery/15.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/16.png">
                <img class="img-responsive" src="images/gallery/16.png" />
            </a>
        </div>
    </div>
</section>