<?php
	require_once('functions/pagecontrolar.php');	
	$oPageContents = new PageContents();
	$oTools=new Tools();
?>