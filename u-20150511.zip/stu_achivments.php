<?php
	require_once('functions/function.php');
	$oPageContents->get_header();
	$oPageContents->get_nav(); 
?>
	<section>
		<div class="full" id="fdBkBanner">
			<div class="container">
                <h1 class="bnrHdr" id="link">student's Achivments</h1>
				<p class="bnrTxt">Creative IT student Achivments</p>
			</div>
			<div class="container">
				<div class="bnrBdr"></div>
			</div>
		</div>
		<!--container end-->
	</section>
	<!--banner part end-->
	<section class="stFdBk">

        <div class="container marB20">
            <p class="evntHtx"><b>Success</b>  <span>stories</span>
            </p>
            <div class="tGraphics ">
                <div class="col-md-4">
                    <a href="" id="video" data-src="5Omkuu610C8">
                        <img src="images/st-fbk/v_09.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="FJakaBHxRt4">
                        <img src="images/st-fbk/v_11.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="crHOf4WnXg8">
                        <img src="images/st-fbk/v_13.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="pnufsqH4nBs">
                        <img src="images/st-fbk/v_23.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="t2nA81vcPgc">
                        <img src="images/st-fbk/v_25.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="igjIxbFOtxU">
                        <img src="images/st-fbk/v_27.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="6wgCB4MoXY4">
                        <img src="images/st-fbk/v_37.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="gBWaLoVBHqg">
                        <img src="images/st-fbk/v_39.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="XQLMDli89Js">
                        <img src="images/st-fbk/v_41.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="V0CjGyXoZXM">
                        <img src="images/st-fbk/v_51.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="Jc9lXT9d1_M">
                        <img src="images/st-fbk/v_53.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="wUAiizh5iVg">
                        <img src="images/st-fbk/v_55.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="DwdIosEVFBA">
                        <img src="images/st-fbk/v_65.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="NnVLmkCUl2g">
                        <img src="images/st-fbk/v_67.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="lfAd9jkLEEI">
                        <img src="images/st-fbk/v_69.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="w_Xjrv7zXuk">
                        <img src="images/st-fbk/v_79.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="57Vqi4hu9hg">
                        <img src="images/st-fbk/v_81.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="lRJsA4pP1bs">
                        <img src="images/st-fbk/v_83.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="XkEDZTPw7IM">
                        <img src="images/st-fbk/v_93.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="kjKQYQjzCCs">
                        <img src="images/st-fbk/v_95.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="3IxSFBHqsxE">
                        <img src="images/st-fbk/v_97.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="SYiC8LAxHUE">
                        <img src="images/st-fbk/v_107.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="vRglmpDZfs4">
                        <img src="images/st-fbk/v_109.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="mR6qV5iz">
                        <img src="images/st-fbk/v_111.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="P9u6MEIK7WU">
                        <img src="images/st-fbk/v_121.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="4KbKwqnIpfs">
                        <img src="images/st-fbk/v_123.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="" id="video" data-src="y9whEvp0Tnw">
                        <img src="images/st-fbk/v_125.jpg" alt="vImage" class="img-responsive">
                    </a>
                </div>
            </div>
        </div>
        <!--Modal for Video-->
        <div class="modal video" tabindex="-1" role="dialog">
            <div class="modal-dialog"> 
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Student Achivments</h4>
                    </div>
                    <iframe id="mVideo" width="100%" height="400" src="" frameborder="0" allowfullscreen></iframe>
                </div>
            </div>
        </div>
        
        <!--Modal for Video End-->
<!--
		<div class="container crsHead">
			<p><b>success </b>stories</p>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/5Omkuu610C8" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/FJakaBHxRt4" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/crHOf4WnXg8" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/pnufsqH4nBs" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/t2nA81vcPgc" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
			<div class="col-md-4">
				<iframe class="img-responsive" src="//www.youtube.com/embed/" frameborder="0" alowfullscreen ></iframe>
			</div>
		</div>
-->
</section>
<div class="container ptBdr"></div>
<?php 
	$oPageContents->get_part('partner_part.php');
	$oPageContents->get_footer();
?>
