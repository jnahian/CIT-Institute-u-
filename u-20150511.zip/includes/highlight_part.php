<section>
    <div class="container pd0 wow fadeInUp" data-nahian-offest="200">
        <div class="col-md-3 pd0 hightLightBg col-sm-6">
            <a href="oneyear_diploma.php#link">
                <span>One Year</span>
                <h2>diploma course</h2>
                <img class="img-responsive" src="images/dip-course.png" alt="diploma">
            </a>
        </div><!--hightLightBg end-->
        <div class="col-md-3 pd0 hightLightBg col-sm-6">
            <a href="apply_seminar.php#link">
                <span>apply for</span>
                <h2>FREE Seminar</h2>
                <img class="img-responsive" src="images/outsourcing.png" alt="diploma">
            </a>
        </div><!--hightLightBg end-->
        <div class="col-md-3 pd0 hightLightBg col-sm-6">
            <a href="online_tutorials.php#link">
                <span>free</span>
                <h2>ONLINE TUTORIALS</h2>
                <img class="img-responsive" src="images/online-tutes.png" alt="diploma">
            </a>
        </div><!--hightLightBg end-->
        <div class="col-md-3 pd0 hightLightBg col-sm-6">
            <a href="apply_online.php#link">
                <span>apply for</span>
                <h2>FREE Scholarship</h2>
                <img class="img-responsive" src="images/free-scholarship.png" alt="diploma">
            </a>
        </div><!--hightLightBg end-->
    </div><!--container end-->
</section><!--hightLightPart end-->