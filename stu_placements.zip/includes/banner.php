<section>
    <div class="full bannerBg"></div>
    <div class="clearfix"></div>
    <div class="sleekslider">
        <!-- Slider Pages -->
        <div class="slide active bg-1">
            <div class="slide-container">
                <div class="slide-content">
                    
                </div>
            </div>
        </div>
        <div class="slide bg-2">
            <div class="slide-container">
                <div class="slide-content">
                    	
                </div>
            </div>				
        </div>
        <div class="slide bg-3">
            <div class="slide-container">
                <div class="slide-content">
                    
                </div>
            </div>				
        </div>
        <div class="slide bg-4">
            <div class="slide-container">
                <div class="slide-content">
                    	
                </div>
            </div>				
        </div>
        <!-- <div class="slide bg-5">
<div class="slide-container">
<div class="slide-content">
<h1>Slide 5 Content Here</h1>	
</div>
</div>				
</div> -->

        <!-- Navigation Arrows with Thumbnails -->
        <!-- <nav class="nav-split">
<a class="prev" href="">
<span class="icon-wrap"><svg class="icon" width="22" height="22" viewBox="0 0 64 64"><use xlink:href="#arrow-left" /></svg></span>
<div>
<h3>test</h3>
<img alt="Previous thumb"/>
</div>
</a>
<a class="next" href="">
<span class="icon-wrap"><svg class="icon" width="22" height="22" viewBox="0 0 64 64"><use xlink:href="#arrow-right" /></svg></span>
<div>
<h3>test</h3>
<img alt="Next thumb"/>
</div>
</a>
</nav> -->


        <!-- Navigation Tabs -->
        <nav class="tabs">
            <div class="tab-container">
                <ul>
                    <li class="current"><a href="#">Latest</a></li>
                    <li><a href="#"> Design</a></li>
                    <li><a href="#">Web</a></li>
                    <li><a href="#">Event</a></li>
                    <!-- <li><a href="#"><span>05</span> Slide</a></li> -->
                </ul>
            </div>
        </nav>
    </div>
    
<!--
   <div class="clearfix"></div>
        <div id="jnn_carousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <img src="images/banner.jpg" alt="...">
                </div>
                <div class="item">
                    <img src="images/banner.jpg" alt="...">
                </div>
                <div class="item">
                    <img src="images/banner.jpg" alt="...">
                </div>
                <div class="item">
                    <img src="images/banner.jpg" alt="...">
                </div>
            </div>
            <div class="container pd0">
                <ol class="bannerTabs">
                    <li data-target="#jnn_carousel" data-slide-to="0" class="active">lattest</li>
                    <li data-target="#jnn_carousel" data-slide-to="1">design</li>
                    <li data-target="#jnn_carousel" data-slide-to="2">web</li>
                    <li data-target="#jnn_carousel" data-slide-to="3">event</li>
                </ol>
            </div>
        </div>
    </div>
-->
<!--
    <div class="container pd0">
        <div class="bannerTabs">
            <ul>
                <li>lattest</li>
                <li>design</li>
                <li>web</li>
                <li>event</li>
            </ul>
        </div>bannerTabs end
    </div>
-->
</section><!--banner part end-->