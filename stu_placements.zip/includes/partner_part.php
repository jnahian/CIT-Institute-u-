<section id="partners">
    <div class="container pd0 partnersPt marB20">
        <div class="partnersHdr text-center marT40">
            <p>creative it</p>
            <h3>partners</h3>
        </div>
        <div class="partners">
            <div>
                <a href="http://creativeit-ltd.com/" target="_blank" title="Creative IT Ltd"><img class="img-responsive" src="images/Logos/1.jpg" alt="Creative IT"></a>
            </div>
            <div>
                <a href="http://creativedeviser.com/" target="_blank" title="Creative Deviser"><img class="img-responsive" src="images/Logos/2.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://www.creativeclippingpath.com" target="_blank" title="Creative Clippingpath"><img class="img-responsive" src="images/Logos/10.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://www.citlearningearning.com" target="_blank" title="Learning Earning"><img class="img-responsive" src="images/Logos/8.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://www.htpbd.org.bd" target="_blank" title="HI-Tech Park"><img class="img-responsive" src="images/Logos/6.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://barirbazar.com/" target="_blank" title="Barir Bazar"><img class="img-responsive" src="images/Logos/3.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://genesisblogs.com" target="_blank" title="Genesis Blog"><img class="img-responsive" src="images/Logos/7.jpg" alt=""></a>
            </div>
            <div>
                <a href="#" target="_blank" title="Spider Network"><img class="img-responsive" src="images/Logos/4.jpg" alt=""></a>
            </div>
            <div>
                <a href="#" target="_blank" title="Hi-Cel"><img class="img-responsive" src="images/Logos/5.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://creativeit-ltd.com/" target="_blank" title="Creative IT Ltd"><img class="img-responsive" src="images/Logos/1.jpg" alt="Creative IT"></a>
            </div>
            <div>
                <a href="http://creativedeviser.com/" target="_blank" title="Creative Deviser"><img class="img-responsive" src="images/Logos/2.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://www.creativeclippingpath.com" target="_blank" title="Creative Clippingpath"><img class="img-responsive" src="images/Logos/10.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://www.citlearningearning.com" target="_blank" title="Learning Earning"><img class="img-responsive" src="images/Logos/8.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://www.htpbd.org.bd" target="_blank" title="HI-Tech Park"><img class="img-responsive" src="images/Logos/6.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://barirbazar.com/" target="_blank" title="Barir Bazar"><img class="img-responsive" src="images/Logos/3.jpg" alt=""></a>
            </div>
            <div>
                <a href="http://genesisblogs.com" target="_blank" title="Genesis Blog"><img class="img-responsive" src="images/Logos/7.jpg" alt=""></a>
            </div>
            <div>
                <a href="#" target="_blank" title="Spider Network"><img class="img-responsive" src="images/Logos/4.jpg" alt=""></a>
            </div>
            <div>
                <a href="#" target="_blank" title="Hi-Cel"><img class="img-responsive" src="images/Logos/5.jpg" alt=""></a>
            </div>
        </div>
    </div><!--container end-->
</section><!--partners part end-->