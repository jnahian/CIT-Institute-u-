$(document).ready(function(){
	$navOffest = $("nav").offset().top; 
	$(".row").height($("nav").outerHeight()); 
	$(window).scroll(function(){
		$scrollPos  = $(window).scrollTop();
		if( $scrollPos >= $navOffest ){
			$("nav").addClass("navbar-fixed-top").css("margin-top","0");
			$(".navBg").css("background","rgba(0,0,0, 1)");
		}
		else{
			$("nav").removeClass("navbar-fixed-top");
			$(".navBg").css("background","rgba(0,0,0, 0.6)");
		}
	});

	// Youtube Video
    
    /*$('a#video').click(function (){ 
        $vId = $(this).attr('href'); 
        $vlink = "https://www.youtube.com/embed/"+$vId+"?autoplay=1";
        //alert($vlink);
        $('.video iframe').attr('src', $vlink);
        
        $('.video').on('hidden.bs.modal', function(){
            $('.video iframe').attr('src', '');
        });
    });*/
    
});
$(window).load(function(){
	$("#loader").fadeOut();
});

new WOW().init();
$(document).ready(function () {
    $('.partners, .slick').slick({
		slidesToShow: 8,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 2000
	});
	$('#Container').mixItUp();
    $('#port, #port1').rebox({
        selector: 'a'
    });

});
$(function () {
	$('[data-toggle="tooltip"]').tooltip()
});
$(function () {
	$('.superbox').SuperBox();
});