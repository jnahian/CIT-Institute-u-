<div class="naCrs">
    <div class="courseBdr">courses</div>
    <div class="allCrs">
        <ul>
            <li <?php if($oTools->get_current_page()=='graphics_details.php'){echo 'class="sideactive"';} ?> ><span class="fa fa-angle-right"></span><a href="graphics_details.php#link">Graphic Design</a>
            </li>
            <li <?php if($oTools->get_current_page()=='webdesign_details.php'){echo 'class="sideactive"';} ?>><span class="fa fa-angle-right"></span><a href="webdesign_details.php#link">Web Design</a>
            </li>
            <li <?php if($oTools->get_current_page()=='webdevelopment_details.php'){echo 'class="sideactive"';} ?>><span class="fa fa-angle-right"></span><a href="webdevelopment_details.php#link">Web Development</a>
            </li>
            <li <?php if($oTools->get_current_page()=='apps_details.php'){echo 'class="sideactive"';} ?>><span class="fa fa-angle-right"></span><a href="apps_details.php#link">Apps Development</a>
            </li>
            <li <?php if($oTools->get_current_page()=='3d_details.php'){echo 'class="sideactive"';} ?>><span class="fa fa-angle-right"></span><a href="3d_details.php#link">3D Animation</a>
            </li>
            <li <?php if($oTools->get_current_page()=='emailmarket_details.php'){echo 'class="sideactive"';} ?>><span class="fa fa-angle-right"></span><a href="emailmarket_details.php#link">Email Marketing</a>
            </li>
            <li <?php if($oTools->get_current_page()=='tvcommerce_details.php'){echo 'class="sideactive"';} ?>><span class="fa fa-angle-right"></span><a href="tvcommerce_details.php#link">TV Commercial</a>
            </li>
            <li <?php if($oTools->get_current_page()=='seo_details.php'){echo 'class="sideactive"';} ?>><span class="fa fa-angle-right"></span><a href="seo_details.php#link">Search Engine Optimization (SEO)</a>
            </li>
            <li <?php if($oTools->get_current_page()=='autocad_details.php'){echo 'class="sideactive"';} ?>><span class="fa fa-angle-right"></span><a href="autocad_details.php#link">Architectual Cad</a>
            </li>
            <li <?php if($oTools->get_current_page()=='ce_details.php'){echo 'class="sideactive"';} ?>><span class="fa fa-angle-right"></span><a href="ce_details.php#link">communecative english</a>
            </li>
        </ul>
    </div>
</div>