<section>
    <div class="full" id="galleryBanner">
        <div class="container">
            <h1 class="bnrHdr" id="link">office GALLERY</h1>
            <p class="bnrTxt">Creative IT staff gallery</p>
        </div><!--container end-->
        <div class="container">
            <div class="bnrBdr"></div>
        </div><!--container end-->
    </div><!--bannerBanner part end-->
</section>
<section>
    <div class="container">
        <div id="port" class="gallery">
            <a class="col-md-3 pd0" href="images/gallery/01.png">
                <img class="img-responsive" src="images/gallery/01.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/02.png">
                <img class="img-responsive" src="images/gallery/02.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/03.png">
                <img class="img-responsive" src="images/gallery/03.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/04.png">
                <img class="img-responsive" src="images/gallery/04.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/05.png">
                <img class="img-responsive" src="images/gallery/05.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/06.png">
                <img class="img-responsive" src="images/gallery/06.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/07.png">
                <img class="img-responsive" src="images/gallery/07.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/08.png">
                <img class="img-responsive" src="images/gallery/08.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/09.png">
                <img class="img-responsive" src="images/gallery/09.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/10.png">
                <img class="img-responsive" src="images/gallery/10.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/11.png">
                <img class="img-responsive" src="images/gallery/11.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/12.png">
                <img class="img-responsive" src="images/gallery/12.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/13.png">
                <img class="img-responsive" src="images/gallery/13.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/14.png">
                <img class="img-responsive" src="images/gallery/14.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/15.png">
                <img class="img-responsive" src="images/gallery/15.png" />
            </a>
            <a class="col-md-3 pd0" href="images/gallery/16.png">
                <img class="img-responsive" src="images/gallery/16.png" />
            </a>
        </div>
    </div>
</section>