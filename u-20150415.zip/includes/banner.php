<section>
    <div class="full bannerBg"></div>
<!--
   <div class="clearfix"></div>
        <div id="jnn_carousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <img src="images/banner.jpg" alt="...">
                </div>
                <div class="item">
                    <img src="images/banner.jpg" alt="...">
                </div>
                <div class="item">
                    <img src="images/banner.jpg" alt="...">
                </div>
                <div class="item">
                    <img src="images/banner.jpg" alt="...">
                </div>
            </div>
            <div class="container pd0">
                <ol class="bannerTabs">
                    <li data-target="#jnn_carousel" data-slide-to="0" class="active">lattest</li>
                    <li data-target="#jnn_carousel" data-slide-to="1">design</li>
                    <li data-target="#jnn_carousel" data-slide-to="2">web</li>
                    <li data-target="#jnn_carousel" data-slide-to="3">event</li>
                </ol>
            </div>
        </div>
    </div>
-->
    <div class="container pd0">
        <div class="bannerTabs">
            <ul>
                <li>lattest</li>
                <li>design</li>
                <li>web</li>
                <li>event</li>
            </ul>
        </div><!--bannerTabs end-->
    </div>
</section><!--banner part end-->