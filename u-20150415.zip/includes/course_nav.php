<section id="courses">
	<div class="container citCourse pd0">
		<div class="col-md-12 pd0 slick" id="crsBody">
			<div class="nahainCc pd0" <?php if($oTools->get_current_page() == 'graphics_details.php'){echo 'id="topactive"'; } ?>>
				<div class="crsBody text-center">
                    <a href="graphics_details.php#link">
                        <span class="flaticon-graphic5"></span>
						<p>graphic design</p>
					</a>
				</div>
				<!--crsBody end-->
			</div>
			<div class="nahainCc pd0" <?php if($oTools->get_current_page() == 'webdesign_details.php'){echo 'id="topactive"'; } ?>>
				<div class="crsBody text-center">
                    <a href="webdesign_details.php#link">
                        <span class="flaticon-website17"></span>
						<p>web design</p>
					</a>
				</div>
				<!--crsBody end-->
			</div>
			<div class="nahainCc pd0" <?php if($oTools->get_current_page() == 'webdevelopment_details.php'){echo 'id="topactive"'; } ?>>
				<div class="crsBody text-center">
                    <a href="webdevelopment_details.php#link">
                        <span class="flaticon-analytics2"></span>
						<p>web development</p>
					</a>
				</div>
				<!--crsBody end-->
			</div>
			<div class="nahainCc pd0" <?php if($oTools->get_current_page() == 'apps_details.php'){echo 'id="topactive"'; } ?>>
				<div class="crsBody text-center">
                    <a href="apps_details.php#link">
						<span class="flaticon-smart"></span>
						<p>apps development</p>
					</a>
				</div>
				<!--crsBody end-->
			</div>
			<div class="nahainCc pd0" <?php if($oTools->get_current_page() == '3d_details.php'){echo 'id="topactive"'; } ?> >
				<div class="crsBody text-center">
                    <a href="3d_details.php#link">
                        <span class="flaticon-3d22"></span>
						<p>3D Animation</p>
					</a>
				</div>
				<!--crsBody end-->
			</div>
            <div class="nahainCc pd0" <?php if($oTools->get_current_page() == 'tvcommerce_details.php'){echo 'id="topactive"'; } ?>>
				<div class="crsBody text-center" >
                    <a href="tvcommerce_details.php#link">
                        <span class="flaticon-television4"></span>
						<p>TV Commercial</p>
					</a>
				</div>
				<!--crsBody end-->
			</div>
			<div class="nahainCc pd0" <?php if($oTools->get_current_page() == 'emailmarket_details.php'){echo 'id="topactive"'; } ?>>
				<div class="crsBody text-center">
                    <a href="emailmarket_details.php#link">
						<span class="flaticon-laptop88"></span>
						<p>Email marketing</p>
					</a>
				</div>
				<!--crsBody end-->
			</div>
            <div class="nahainCc pd0" <?php if($oTools->get_current_page() == 'seo_details.php'){echo 'id="topactive"'; } ?>>
				<div class="crsBody text-center">
                    <a href="seo_details.php#link">
                        <span class="flaticon-search100"></span>
						<p>seo</p>
					</a>
				</div>
				<!--crsBody end-->
			</div>
			<div class="nahainCc pd0" <?php if($oTools->get_current_page() == 'autocad_details.php'){echo 'id="topactive"'; } ?>>
				<div class="crsBody text-center">
                    <a href="autocad_details.php#link">
                        <span class="flaticon-scale3"></span>
						<p>Architectual Cad</p>
					</a>
				</div>
				<!--crsBody end-->
			</div>
            <div class="nahainCc pd0" <?php if($oTools->get_current_page() == 'ce_details.php'){echo 'id="topactive"'; } ?>>
				<div class="crsBody text-center">
                    <a href="ce_details.php#link">
                        <span class="flaticon-man216"></span>
						<p>communecative english</p>
					</a>
				</div>
				<!--crsBody end-->
			</div>
		</div>
		<!--#crsBody end-->
	</div>
	<!--creative link end-->
</section>